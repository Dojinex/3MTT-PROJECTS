# Scalable Node.js REST API

This project is a simple and scalable REST API using Node.js and Express. It supports concurrent connections and validates user input.

## Features
- Express-based routing
- In-memory user database
- Custom input validation
- Non-blocking I/O
- Supports GET and POST endpoints

## How to Run

```bash
npm install
node server.js
```

Test with Postman, Thunder Client, or CURL.

## API Endpoints

### GET /api/users
Fetch all users.

### POST /api/users
Create a new user.

#### Request Body
```json
{
  "name": "Your Name",
  "email": "your@email.com"
}
```

## Example Response
```json
{
  "user": {
    "id": 1,
    "name": "John",
    "email": "john@example.com"
  }
}
```
