const express = require('express');
const router = express.Router();

// In-memory users array
const users = [];

// GET all users
router.get('/', (req, res) => {
  res.status(200).json({ users });
});

// POST new user with validation
router.post('/', (req, res) => {
  const { name, email } = req.body;

  if (!name || typeof name !== 'string') {
    return res.status(400).json({ error: 'Name is required and must be a string.' });
  }

  if (!email || !email.includes('@')) {
    return res.status(400).json({ error: 'A valid email is required.' });
  }

  const user = { id: users.length + 1, name, email };
  users.push(user);
  res.status(201).json({ user });
});

module.exports = router;
